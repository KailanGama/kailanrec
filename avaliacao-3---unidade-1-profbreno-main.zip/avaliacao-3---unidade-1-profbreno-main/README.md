# Disciplina: Linguagem de Programação I - IFBA Euclides da Cunha

## PROVA DE RECUPERAÇÃO - UNIDADE 1

### Entrega até 23/09/2021 às 23:59

### **Implementar os seguintes requisitos**

- Acrescente mais dois tipos de atributos na classe Produto, a seu critério,
  como por exemplo, um atributo para armazenar o preço de custo e outro para
  armazenar o preço de venda, usando encapsulamento.
- Acrescente um método na classe Produto para calcular o lucro do produto,
  que deve ser o preço de venda menos o preço de custo.
- Crie uma classe RepositórioPedidos que armazene os pedidos de um supermercado.
  Essa classe deve ser capaz de gerar um relatório de vendas do dia.
- A classe principal deve ser capaz de adicionar mais de um pedido, calcular o
  valor total de cada pedido e gerar o relatório de vendas ao final do di, incluíndo
  lucro adquirido.
